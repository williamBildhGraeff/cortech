from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import HttpResponse
from pesagens.validators.import_export_validators import ImportExportValidator
import csv
from animais.models import Animal

class ExportarCsvPesagem(APIView):
    def get(self, request):
        lote_id = request.GET.get("lote_id")
        ImportExportValidator.validar_exportar_pesagem(lote_id)
        animais = (
            Animal.objects
            .filter(lote_id=lote_id)
            .prefetch_related('pesagens')
        )

        max_pesagens = max(
            (animal.pesagens.count() for animal in animais),
            default=0
        )

        dados = []

        for animal in animais:
            pesagens = animal.pesagens.all().order_by('data')

            linha = {
                'brinco': animal.brinco,
                'pesagens': [],
                'gmd_medio': None
            }

            gmds = []

            for p in pesagens:
                linha['pesagens'].append({
                    'data': str(p.data),
                    'peso': str(p.peso),
                    'gmd_calculado_automatico': (
                        str(p.gmd_calculado_automatico)
                        if p.gmd_calculado_automatico else ""
                    )
                })

                if p.gmd_calculado_automatico:
                    gmds.append(float(p.gmd_calculado_automatico))

            linha['gmd_medio'] = sum(gmds) / len(gmds) if gmds else None
            dados.append(linha)

        resultado = {
            'max_pesagens': max_pesagens,
            'dados': dados
        }

        response = HttpResponse(
            content_type='text/csv; charset=utf-8'
        )
        response['Content-Disposition'] = (
            f'attachment; filename="pesagens_lote_{lote_id}.csv"'
        )

        writer = csv.writer(response, delimiter=';')
        header = ['Brinco']    
        for i in range(1, resultado['max_pesagens'] + 1):
            header += [f'data_{i}', f'peso_{i}', f'gmd_{i}']
        header.append("gmd_medio")
        writer.writerow(header)

        for item in resultado['dados']:
            linha = [item['brinco']]
            for pesagem in item['pesagens']:
                linha.append(pesagem['data'])
                linha.append(pesagem['peso'])
                linha.append(pesagem['gmd_calculado_automatico'])
            # Preencher vazios
            faltam = resultado['max_pesagens'] - len(item['pesagens'])
            linha += ['-', '-', '-'] * faltam
            linha.append(item['gmd_medio'])
            writer.writerow(linha)  

        return response
